# Admin Dir

```plaintext
includes/
├── admin/
│   ├── class-mgwpp-admin.php
│   ├── class-security-scanner.php
│   ├── views/
│   │   ├── class-dashboard-view.php
│   │   ├── class-albums-view.php
│   │   ├── class-galleries-view.php
│   │   ├── class-testimonials-view.php
│   │   └── class-security-view.php
│   └── tables/
│       ├── class-storage-table.php
│       ├── class-suspicious-files-table.php
│       └── class-albums-table.php
```
