<?php

declare(strict_types=1);

use PHPUnit\Framework\TestCase;

final class MiniGalleryTests extends TestCase
{
    public function testPluginFuncs()
    {
       
    }
};
